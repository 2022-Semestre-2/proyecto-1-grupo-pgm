/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller;

import Frames.IniPantalla;

/**
 * Clase principal para iniciar todo el programa
 * @author Pablo R. Z.
 * @version 2.0
 */
public class App {
    public static void main( String[] args ){
        IniPantalla p = new IniPantalla();
        p.setVisible(true);

    } 
}