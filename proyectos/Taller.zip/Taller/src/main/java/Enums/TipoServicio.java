/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Enums;

/**
 * constantes de los tipos de servicio
 * @author ttc46
 */
public enum TipoServicio {
    MECANICA,ENDEREZADOPINTURA;
}