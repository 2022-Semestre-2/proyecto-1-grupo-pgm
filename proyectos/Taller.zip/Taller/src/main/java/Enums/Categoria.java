/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Enums;

/**
 *
 * @author Usuario
 */
public enum Categoria {
    SEDAN, _4X4, PICKUP, SUV,CROSSOVER,HATCHBACK,COUPE,STATION_WAGON,CONVERTIBLE,MPV
}
