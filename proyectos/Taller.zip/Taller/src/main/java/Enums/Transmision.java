/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Enums;

/**
 * constantes de lso tipos de tansmision
 * @author ttc46
 */
public enum Transmision {
    MANUAL,AUTOMATICA,SECUENCIAL;
}